import tkinter as tk

def button_click_handler():
  print("Hello I'm Mohammed Insaf!")

root = tk.Tk()

button = tk.Button(root, text="Click My Page", command=button_click_handler)
button.pack()

root.mainloop()