def bubble_sort(data):

    length = len(data)
    for i in range(length - 1):
        for j in range(length - i - 1):
            if data[j] > data[j + 1]:
                data[j], data[j + 1] = data[j + 1], data[j]

data = [5, 2, 4, 9, 1, 6, 3, 8, 10]
bubble_sort(data)
print(data)