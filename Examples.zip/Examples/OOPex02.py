class Car:
  def __init__(self, model, color, year, engine_size):
    self.model = model
    self.color = color
    self.year = year
    self.engine_size = engine_size

  def start_engine(self):
    print("The engine of the " + self.model + " has started.")

  def accelerate(self):
    print("The " + self.color + " " + self.model + " is accelerating.")

  def stop_engine(self):
    print("The engine of the " + self.model + " has stopped.")

# Create an instance of the Car class
my_car = Car("Toyota Camry", "silver", 2022, 2.5)

# Print the attributes of the my_car object
print("Model:", my_car.model)
print("Color:", my_car.color)
print("Year:", my_car.year)
print("Engine size:", my_car.engine_size)

# Call the methods of the my_car object
my_car.start_engine()
my_car.accelerate()
my_car.stop_engine()