# Calculates the area of a rectangle.
def calculate_area(length, width):

  area = length * width
  return area

def main():

  length = float(input("Enter the length: "))
  width = float(input("Enter the width: "))

  area = calculate_area(length, width)

  print("Area of rectangle is:", area)

if __name__ == "__main__":
  main()